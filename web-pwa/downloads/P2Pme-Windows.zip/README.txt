============================================================
P2Pme - Secure Photo Backup & Direct Sync for Windows
============================================================

Quick Start:
1. Double-click "p2pme_app.exe" (or "Launch_P2Pme.cmd") to start the Desktop GUI.
2. The Nearby tab will automatically discover your Android phone or iPad on the same Wi-Fi.
3. Tap "Pair for Backup" or "Send Photos" to transfer at maximum Wi-Fi speed.

For Command-Line / Server Usage:
- Double-click or run "p2pme.exe" from a terminal for the interactive menu or CLI daemon.

Zero-Cloud • Direct Wi-Fi P2P • TLS 1.3 Encryption • BLAKE3 Cryptographic Chunking
Website: https://p2pme.pages.dev
