@echo off
start "" "%~dp0p2pme_app.exe"

